# Where can I learn more about Manim's internal structure?

Efforts to document the internal structure of Manim is ongoing on our
[wiki](https://github.com/ManimCommunity/manim/wiki/Developer-documentation-(WIP)).

Keep in mind that since this is a work in progress, the information you find may be
incomplete, outdated or even wrong. Still, it should serve as a good starting point.
The wiki is open for anyone to edit, feel free to add information or even questions
directly on the wiki pages.
