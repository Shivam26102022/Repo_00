Animations
==========

.. currentmodule:: manim

.. autosummary::
   :toctree: ../reference

   ~animation.animation
   ~animation.changing
   ~animation.composition
   ~animation.creation
   ~animation.fading
   ~animation.growing
   ~animation.indication
   ~animation.movement
   ~animation.numbers
   ~animation.rotation
   ~animation.specialized
   ~animation.speedmodifier
   ~animation.transform
   ~animation.transform_matching_parts
   ~animation.updaters
