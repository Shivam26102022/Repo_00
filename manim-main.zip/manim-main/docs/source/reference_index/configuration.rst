Configuration
=============

Module Index
------------

.. currentmodule:: manim

.. autosummary::
   :toctree: ../reference

   ~_config
   ~_config.utils
   ~_config.logger_utils
