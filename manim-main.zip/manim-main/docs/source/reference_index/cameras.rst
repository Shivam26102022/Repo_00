Cameras
=======

.. currentmodule:: manim

.. autosummary::
   :toctree: ../reference

   ~camera.camera
   ~camera.mapping_camera
   ~camera.moving_camera
   ~camera.multi_camera
   ~camera.three_d_camera
