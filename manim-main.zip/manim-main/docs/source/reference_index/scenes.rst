Scenes
======

.. currentmodule:: manim

.. autosummary::
   :toctree: ../reference

   ~scene.moving_camera_scene
   ~scene.section
   ~scene.scene
   ~scene.scene_file_writer
   ~scene.three_d_scene
   ~scene.vector_space_scene
   ~scene.zoomed_scene
