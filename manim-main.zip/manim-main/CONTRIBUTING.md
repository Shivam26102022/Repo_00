# Thanks for your interest in contributing!

Please read our contributing guidelines which are hosted at https://docs.manim.community/en/latest/contributing.html
